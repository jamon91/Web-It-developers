Aqui van los archivos de:
AlmacenarRespaldo.php
DescargarRespaldo.php
ActualizarRespaldo.php
VerificarRespaldo.php

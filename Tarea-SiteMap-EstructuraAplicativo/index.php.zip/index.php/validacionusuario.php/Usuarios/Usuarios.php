Aqui van los archivos de:
RegistrarUsuario.php
ModificarUsuario.php
ActualizarUsuario.php
RestablecerContraseña.php

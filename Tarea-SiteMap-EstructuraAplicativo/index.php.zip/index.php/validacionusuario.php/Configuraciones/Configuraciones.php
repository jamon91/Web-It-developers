Aqui van los archivos de:
ConfiguracionVM.php
ConfiguracionRespaldos.php
ConfiguracionOS.php
ConfiguracionPOS.php

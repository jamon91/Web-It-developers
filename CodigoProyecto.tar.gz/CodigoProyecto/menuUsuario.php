<?php

?>

<!DOCTYPE html>
<html>

<head>
    <title>
        Mantenimiento de Usuarios
    </title>
    <link rel="stylesheet" type="text/css" href="css/style.css">

</head>

<body>
    <div class="container">
        <div class="header">
            <br><h1>Men&uacute; de usuarios</h1><br><br><br>
        </div>
        <div class="decorate">
        </div>
        <div class="interface">
            <br><br>
            <table>
                <tr>
                    <th><h2>Registrar Usuarios </h2></th>
                    <th><a href="Usuarios/registrarUsuario.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Modificar Usuarios</h2></th>
                    <th><a href="Usuarios/modificarUsuario.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Consultar Usuarios</h2></th>
                    <th><a href="Usuarios/consultarUsuario.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Cambiar Contrasena</h2></th>
                    <th><a href="Usuarios/reestablecerContrasena.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Menu principal</h2></th>
                    <th><a href="menuPrincipal.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
            </table>
        </div>
    </div>
    <p>
        Web/It Developers
    </p>
</body>
</html>
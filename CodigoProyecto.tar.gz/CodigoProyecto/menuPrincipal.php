<?php

?>

<!DOCTYPE html>
<html>

<head>
    <title>
        Men&uacute principal
    </title>
    <link rel="stylesheet" type="text/css" href="css/style.css">

</head>

<body>
    <div class="container">
        <div class="header">
            <br><h1>Men&uacute; principal</h1><br><br><br>
        </div>
        <div class="decorate">
        </div>
        <div class="interface">
            <br><br>
            <table>
                <tr>
                    <th><h2>Usuarios </h2></th>
                    <th><a href="menuUsuario.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Respaldos</h2></th>
                    <th><a href="menuRespaldos.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Configuraciones</h2></th>
                    <th><a href="Configuraciones/VMConfiguracion.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Login</h2></th>
                    <th><a href="index.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
            </table>
        </div>
    </div>
    <p>
        Web/It Developers
    </p>
</body>

</html>
<?php
/**
 * Created by PhpStorm.
 * User: estudiante
 * Date: 11/04/15
 * Time: 11:44 AM
 */

namespace createClient;


class amazonS3 {



}
<?php

?>

<!DOCTYPE html>
<html>

<head>
    <title>
        Mantenimiento de Respaldos
    </title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <div class="container">
        <div class="header">
            <br><h1>Men&uacute; de respaldos</h1><br><br><br>
        </div>
        <div class="decorate">
        </div>
        <div class="interface">
            <br><br>
            <table>
                <tr>
                    <th><h2>Almacenar respaldo </h2></th>
                    <th><a href="Respaldos/almacenarRespaldo.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Descargar respaldo</h2></th>
                    <th><a href="Respaldos/descargarRespaldo.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Actualizar respaldo</h2></th>
                    <th><a href="Respaldos/actualizarRespaldo.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Verificar respaldo</h2></th>
                    <th><a href="Respaldos/verificarRespaldo.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
                <tr>
                    <th><h2>Menu principal</h2></th>
                    <th><a href="menuPrincipal.php"><img src="imag/ir.jpg"title="	"></a></th>
                </tr>
            </table>
        </div>
    </div>
    <p>
        Web/It Developers
    </p>
</body>

</html>
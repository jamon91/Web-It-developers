function clickSimple() {
    alert('Nombre de usuario');
}

function validarDatos() {
    alert('Validando datos...');

}